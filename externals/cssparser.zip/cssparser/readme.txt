The original CSS parser can be found at https://github.com/sabberworm/PHP-CSS-Parser

This fork adds customizations that allow it to work with the Origin framework.